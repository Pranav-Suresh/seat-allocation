import React from "react";
import {render} from "react-dom";
import {Login} from "./components/Login";
import {UserPage} from "./components/UserPage"

class App extends React.Component {
	render() {
		return(
				<UserPage/>
			);
	}	
}

export default App;