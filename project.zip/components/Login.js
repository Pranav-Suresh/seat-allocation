import React from "react";
import {render} from "react-dom";

export class Login extends React.Component {
	render() {
		return(
				<div className="containerLogin">
					<h1>SEAT MANAGEMENT PORTAL</h1>
					<img src="./assets/loginImage.png" alt="Cognizant"/> 
					<div className="form-group">
						<label htmlFor="userid">Associate ID </label>
						<input type="number" className="form-control" id="userid"/>
						<p></p>
						<label htmlFor="password">Password</label>
						<input type="password" className="form-control" id="password" />
						<p></p>
						<button className="btn btn-primary">Login</button>
					</div>
					
				</div>
			);

	}
} 