import React from "react";
import {render} from "react-dom";

export class Admin extends React.Component {
	render() {
		return(
				<div>
					
				</div>
			);
	}	
}